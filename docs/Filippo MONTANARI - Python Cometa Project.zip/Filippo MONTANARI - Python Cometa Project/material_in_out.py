import PySimpleGUI as sg
import different_operations as dops

'''
This file contains the functions necessary for the insertion of the material 
entering and exiting the stock. The input data is checked and used to update the
database framework.
1) check function
2) record entering material
3) record exiting material
'''
# --------------------------------------------
def checks(dbase, material, weight, io):
    '''
    Function that checks if the inserted values are valid and asks the user
    for a confirm.
    material: str, name of the material
    weight: str, weight of the material (to be converted into int)
    io: str, i=entering material, o=exiting material
    dbasedbase: framework containing the database
    '''
    # check if material is "in" or "out"
    if io == 'i':
        io = 'entrata'
    elif io == 'o':
        io = 'uscita'
    else:
        raise ValueError('The "checks" function only accepts io = "i"/"o"')
    
    # check if values are valid
    try:
        if material not in dops.get_dbase_column_as_list(dbase, 'material'):
            sg.Popup('Materiale non valido.',
                     'Per aggiungere un materiale clicca su "Modifica i materiali del database"')
            return None
        elif (weight == '' or int(weight)<=0) and io == 'entrata':
            sg.Popup("Inserisci una quantita' valida.")
            return None
        else:
            # values are valid, then ask the user for a confirm and return his choice
            confirm = sg.popup_yes_no('Materiale in ' + io.upper() + ':\nVuoi inserire ' + weight + ' kg di ' + material.lower() + ' in ' + io + '?',title=('Conferma'))
            return confirm
    except:
        sg.popup('Problema con la registrazione del materiale in entrata, riprova.')
        return None

# --------------------------------------------
def in_material(file, dbase, material, weight):
    '''
    Function called when a new enetring material is inserted by the user. It calls
    the "checks" function to validate user's input, and then updates data inside 
    the database framework.
    material: str, name of the material
    weight: str, weight of the material (to be converted into int)
    dbasedbase: framework containing the database
    '''
    confirm = checks(dbase, material, weight, 'i')
    
    if confirm == 'Yes':
        # --- data registration ---
        # new weight
        index = dops.get_indexes(dbase, material)[0][0] # search the "material" index
        old_weight = dbase.loc[index, 'weight'].strip(' kg') # str
        new_weight = str(int(old_weight) + int(weight)) + ' kg' # str
        dbase.at[index, 'weight'] = new_weight # update the weight
        
        # new tot_value
        quotation = dbase.at[index, 'quotation'] # str
        dbase.at[index, 'tot_value'] = dops.calculate_tot_value(new_weight, quotation)
        
        
        dbase.to_csv(file, index=False) # update the .txt file
    return dbase

# --------------------------------------------
def out_material(file, dbase, material, weight):
    '''
    Function called when a new exiting material is inserted by the user. It calls
    the "checks" function to validate user's input, and then updates data inside 
    the database framework.
    material: str, name of the material
    weight: str, weight of the material (to be converted into int)
    dbasedbase: framework containing the database
    '''
    confirm = checks(dbase, material, weight, 'o')
    
    if confirm == 'Yes':
        # --- data registration ---
        # new weight
        index = dops.get_indexes(dbase, material)[0][0] # search the "material" index
        old_weight = dbase.at[index, 'weight'].strip(' kg') # str
        new_weight = int(old_weight) - abs(int(weight)) # int
        
        # we verifiy that the weight of stocked material is >= 0
        if new_weight < 0:
            confirm = sg.popup_yes_no("La quantita' di " + material.lower() + " registrata in stock è inferiore alla quantita' che desideri rimuovere. Vuoi ridurre la quantita' di " + material.lower() + ' in stock a zero?',title=('Attenzione'))
            if confirm == 'Yes':
                dbase.at[index, 'weight'] = '0 kg'
                new_weight = 0
                
        else:
            dbase.at[index, 'weight'] = str(new_weight) + ' kg'
        
        # new tot_value
        quotation = dbase.at[index, 'quotation'] # str
        new_weight = str(new_weight) + ' kg' # str
        dbase.at[index, 'tot_value'] = dops.calculate_tot_value(new_weight, quotation)
        
        dbase.to_csv(file, index=False) # update the .txt file
        
    return dbase
    
    
    
    
    
