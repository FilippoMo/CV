import PySimpleGUI as sg
import different_operations as dops

'''
The functions in this file are those necessary to manage the database:
1) open the window showing database content
2) add a new material to the database
3) delete materials from the database
4) modify a material inside the database
'''

#%% --- OPEN the window showing DATABASE EDITING PANEL --- #
def open_window(file, dbase, win_icon):
    '''
    This function opens the window showing the database table.
    dbase: framework containing the database
    theme: str, name of the theme
    win_icon: str, name of the .ico file shown on top-left corner of the window
    '''
    
    table_heads = ['material','weight','quotation','tot_value','zone']
    indexes = list(dbase.index.values)
    
    
    # --- layout elements definition --- #
    headings = ["Materiale", "Quantita'", "Quotazione", "Valore in stock", "Zona di stoccaggio"]
    header =  [[sg.Text('     ')] + [sg.Text(h,size=(15,1),justification='center') for h in headings]]
    
    options_buttons = [[sg.Text('    '), sg.Button(button_text='Aggiungi nuovo materiale',key='-ADD-'), 
                            sg.Button(button_text='Elimina materiali',key='-DEL-'), 
                            sg.Button(button_text='Modifica materiali',key='-EDIT-')]]
    close_button = [[sg.Text(' '*150), sg.Cancel(button_text='Salva e chiudi',size=(10,1))]]
    
    rows = dops.text_table_layout(dbase,indexes,table_heads,checkbox=True)
            
    # --- layout composition --- #
    layout = header + rows + options_buttons + close_button
      
    
    # --- Window opening --- #
    dbase_window = sg.Window('Materiali in stock', layout, icon=win_icon, grab_anywhere=True, modal=True)
    
    event = ''
    while event != 'Salva e chiudi' and event != sg.WIN_CLOSED:
        event, values = dbase_window.read()
        
        # 1) add a new material to the database
        if event == '-ADD-':
            ans = add_new_material(dbase, win_icon)
            if not ans is None:
                dbase = ans
                # database saved in .txt file
                dbase.to_csv(file, index=False) # update the .txt file
                # the window is closed and reopened with the updates database
                dbase_window.close()
                return open_window(file, dbase, win_icon)
        
        # 2) delete materials of database
        elif event == '-DEL-':
            ans = delete_materials(dbase, values)
            if not ans is None:
                dbase = ans
                # database saved in .txt file
                dbase.to_csv(file, index=False) # update the .txt file
                # the window is closed and reopened with the updates database
                dbase_window.close()
                return open_window(file, dbase, win_icon)
        
        # 3) edit a material information insidie of the database
        elif event == '-EDIT-':
            ans = edit_material(dbase, values, win_icon)
            if not ans is None:
                dbase = ans
                # database saved in .txt file
                dbase.to_csv(file, index=False) # update the .txt file
                # the window is closed and reopened with the updates database
                dbase_window.close()
                return open_window(file, dbase, win_icon)
        
    dbase_window.close()
    return dbase
    






#%% --- ADD a new material to the database --- #
def add_new_material(dbase, win_icon):
    
    layout = [
        [sg.Text('Nome', size=(15,1),justification='right'), 
         sg.InputText(size=(15, 1), key='material')],
        [sg.Text("Quantita' in stock", size=(15,1),justification='right'), 
         sg.InputText(size=(15, 1), key='weight'), sg.Text('kg')],
        [sg.Text('Quotazione', size=(15,1),justification='right'), 
         sg.InputText(size=(15, 1), key='quotation'), sg.Text('€/kg')],
        [sg.Text('Zona di stoccaggio', size=(15,1),justification='right'), 
         sg.InputText(size=(15, 1), key='zone')],
        
        [sg.Text('                 '),
         sg.Submit(button_text='Conferma',tooltip='Clicca per confermare',key='-CONFIRM-'),
         sg.Cancel(button_text='Annulla')]
    ]
    
    
    add_material_window = sg.Window('Aggiungi un nuovo materiale', layout, icon=win_icon, modal=True)
    
    event = ''
    while event != 'Annulla' and event != sg.WIN_CLOSED:
        event, values = add_material_window.read()
        
        if event == '-CONFIRM-':
            ans, values = check_new_material_insertion(dbase, values)
            if ans == True:
                values['tot_value'] = dops.calculate_tot_value(values['weight'], values['quotation'])
                dbase = dbase.append(values, ignore_index=True)
                new_dbase = dbase.sort_values(by='material')
                # close the window and return the new dbase
                add_material_window.close()
                return new_dbase
                  
    add_material_window.close()
    return None


# --- verify if the new material and the associated information are valid --- #
def check_new_material_insertion(dbase, input_values, check_name=True):
    # --- checks ---
        # check if quantity is valid:
    for digit in input_values['weight']:
        if not digit in '0123456789': # the quantity must be decimal and non-negative
            sg.Popup("Quantità non valida.\nInserisci un numero intero.")
            return False, input_values
    
        # check if name is not already present:    
    if check_name == True:
        if input_values['material'] in dops.get_dbase_column_as_list(dbase,'material'):
            sg.Popup("Un materiale con lo stesso nome è già presente all'interno del database.")
            return False, input_values
    
        # check if quotation is valid (>0 and a float):
    try:
        temp_quotation = float(input_values['quotation'].replace(',','.'))
        if temp_quotation<=0:
            sg.Popup("Quotazione non valida.")
            return False, input_values
        else:
            input_values['quotation'] = str("{:.2f}".format(temp_quotation)) # set decials number to 2
    except:
        sg.Popup("Quotazione non valida.\nLa quotazione deve essere specificata e avere un valore maggiore di zero.")
        return False, input_values
    
    # --- formatting input data ---
    if input_values['weight'] == '':
        input_values['weight'] = '0 kg'
    else:
        input_values['weight'] = input_values['weight'] + ' kg'
    
    input_values['quotation'] = input_values['quotation'].replace('.',',') + ' €/kg'
    
    if input_values['zone'] == '':
        input_values['zone'] = '-non specificata-'
    
    return True, input_values
      






#%% --- DELETE materials from the database --- #
def delete_materials(dbase, materials_to_delete):
    '''
    This function deletes the selected materials from the database and returns it.
    dbase: framework containing the database
    materials_to_delete: dict, giving the information about which material has to be deleted
    '''
    
    # table_heads = list(dbase.columns.values)
    # indexes = list(dbase.index.values)
    
    # the keys of the 'materials_to_delete' disctionary are equal to the indexes 
    # of the materials inside the dbase
    temp_to_del = []
    string_to_del = ''
    # in the temporary file we save the indexes of the materials to delete
    for key in materials_to_delete.keys():
        if materials_to_delete[key] == True:
            temp_to_del.append(int(key))
            string_to_del += '  -- ' + str(dbase.at[int(key), 'material']) + '\n'
    
    if len(temp_to_del)>0:
        confirm = sg.popup_yes_no('Vuoi eliminare dal database i seguenti materiali?\n' + string_to_del)
        if confirm == 'Yes':
            dbase = dbase.drop(temp_to_del)
            new_dbase = dbase.sort_values(by='material')
            return new_dbase
    
    return None







#%% --- EDIT a material inside the database --- #
def edit_material(dbase, values, win_icon):
    
    # we check which materials have been checked and thus are to be modified
    indexes_to_modify = []
    for key in values.keys():
        # key is <class 'numpy.int64'>
        if values[key] == True:
            indexes_to_modify += [key]
            
    if len(indexes_to_modify) == 0:
        return None # if no material was chosen (no checks) return None
    
    
    # --- CREATION OF THE GUI WINDOW --- #
    table_heads = ['material','weight','quotation','zone']
        
    # --- layour elements definition --- #
    headings = ["Materiale", "Quantità in kg", "Quotazione in €/kg ", "Zona di stoccaggio  "]
    header =  [[sg.Text(h,size=(15,1),justification='center') for h in headings]]
    
    confirm_button = [sg.Text(' '*91), sg.Submit(button_text='Salva e chiudi',size=(10,1))]
    cancel_button = [sg.Cancel(button_text='Annulla', tooltip='Chiudi senza salvare')]
    
    rows = dops.input_table_layout(dbase,indexes_to_modify,table_heads)

    # --- layout composition --- #
    layout = header + rows + [[sg.Text(' ')]] + [confirm_button + cancel_button]
      
    # --- Window opening --- #
    edit_material_window = sg.Window('Modifica i materiali in stock', layout, icon=win_icon, modal=True)
    
    
    while True:
        event, values = edit_material_window.read()
        
        if event == 'Annulla' or event == sg.WIN_CLOSED:
            edit_material_window.close()
            return dbase
        
        elif event == 'Salva e chiudi':
            
            # first of all we save the old values in a dictionary in the same format
            # of the new values. 
            # Eg: {'material0': 'Copper', 'weight0': '124 kg', ... , 'quotation4': '12,5 €/kh', 'zone4': 'courtyard'}
            old_values = dops.get_dict_with_dataframe_values(dbase,indexes_to_modify,table_heads)
            
            # after that, we check if new information is valid and return the formatted 
            # dictionary containing the formatted values
            valid, new_values = check_edited_material(dbase, values)
            
            if valid == True:
                
                # CHECK 1: we verify that at least one thing has been changed
                nothing_changed = True
                for key in list(old_values.keys()):
                    if old_values[key] != new_values[key]:
                        nothing_changed = False
                        
                if nothing_changed == True:
                    edit_material_window.close()
                    return dbase # if nothing changed, we simply close the window and return the dbase
                
                # CHECK 2: we verify that the inserted material names don't exist already
                valid = True
                # for each new name, check if it already exists in the database and it is not one
                # of those selected for modifications!: of course if "Copper" was chosen, and only its 
                # quotation (and not its name) wa changed, the inserted information is still valid,
                # this is why the code part "and not material in list(old_values.values())[::4]" is necessary.
                for material in list(new_values.values())[::4]:
                    if material in dops.get_dbase_column_as_list(dbase,'material') and not material in list(old_values.values())[::4]:
                        valid = False
                        sg.Popup((" Il nome " + material + " è già registrato.\nClicca OK e cambialo per procedere" ), title='Errore')
                
                
                # CHECK 1 and 2 are passed => we update dbase values
                if valid == True:
                    
                    for key in list(new_values.keys()):
                        dbase.at[int(key.split(' ')[1]), key.split(' ')[0]] = new_values[key]
                    # calculating and updating the new stock values with the 
                    # "dops.calculate_tot_value(weight, quotation)" function
                    for i in indexes_to_modify:
                        weight = new_values['weight ' + str(i)]
                        quotation = new_values['quotation ' + str(i)]
                        dbase.at[i, 'tot_value'] = dops.calculate_tot_value(weight, quotation)
                                        
                    new_dbase =  dbase.sort_values(by='material')
                    edit_material_window.close()
                    return new_dbase
            

# --- verify if the new information is valid --- #
def check_edited_material(dbase, input_values):
    '''
    dbase = pandas dataframe
    input_values = dictionary {key: value}
    
    Returns valid=True if the input_values are valid for the "check_new_material_insertion"
    function. Furthermore, it returns a new dictionary with formatted keys and data so 
    as to be compared with the old_values.
    output_values format: {'material0': 'Copper', 'weight0': '124 kg', ... , 'quotation4': '12,5 €/kh', 'zone4': 'courtyard'}
    '''
    
    # for each material to modify we ckech its validity: True means valid, False means not valid
    valid_list = []
    
    keys_list = list(input_values.keys()) # = ['material0', 'weight0', ... , 'quotation3', 'zone3', ...]
    
    
    output_values = {}
    header = ['material','weight','quotation','zone']
    
    for i in range(0, len(keys_list), 4):
        values = {}
        for j in range(4):
            # preparing the dictionary to enter the check function
            values[header[j]] = input_values[keys_list[i+j]]
            
        valid, values = check_new_material_insertion(dbase, values, check_name=False)
        valid_list.append(valid)
        
        # we need a separate cycle since all date must be formatted with the 
        # "check_new_material_insertion" function before being saved in dictionary output_values
        for j in range(4):
            output_values[keys_list[i+j]] = values[header[j]]
    
    return all(valid_list), output_values
    

