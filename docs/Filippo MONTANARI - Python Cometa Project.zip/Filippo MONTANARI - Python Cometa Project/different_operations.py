import PySimpleGUI as sg

'''
'''

def get_dbase_column_as_list(dbase, column_head):
    '''
    This small function returns a list containing the values of a database column
    '''
    materials = dbase[column_head].tolist()
    return materials



def sort_db_by_last_insertion(dbase):
    '''
    This small function returns the database with alphabetically sorted material
    '''
    new_dbase = dbase.sort_values(by='last_insertion')
    return new_dbase



def calculate_tot_value(weight, quotation):
    '''
    Computes weight*quotation, returning the total value of the material in stock
    weight, quotation and value are strings.
    '''
    weight = int(weight.strip(' kg'))
    quotation = float(quotation.replace(',','.').strip(' €/kg'))
    
    value = "{:.2f}".format(weight*quotation) # set decials number to 2
    value = str(value).replace('.',',') + ' €' 
    
    return value # value = weight*quotation



def get_indexes(dataframe, value):
    '''
    Get index positions of value in dataframe i.e. dfObj.
    listOfPos = [[row0, col0], [row1, col1], ...]
    
    '''
    listOfPos = list()
    # Get bool dataframe with True at positions where the given value exists
    result = dataframe.isin([value])
    # Get list of columns that contains the value
    seriesObj = result.any()
    columnNames = list(seriesObj[seriesObj == True].index)
    # Iterate over list of columns and fetch the rows indexes where value exists
    for col in columnNames:
        rows = list(result[col][result[col] == True].index)
        for row in rows:
            listOfPos.append([row, col])
    # Return a list of tuples indicating the positions of value in the dataframe
    return listOfPos



def text_table_layout(dbase,indexes,table_heads,checkbox=False):
    '''
    
    '''
    if len(indexes)>0:
        data_rows = []
        for i in indexes:
            row = []
            if checkbox == True:
                row.append(sg.Checkbox('',default=False,key=i))
            for c in range(len(table_heads)):
                text = (dbase.at[i, table_heads[c]]) # this text is read inside the dataframe 'dbase'
                row += [sg.Text(text,size=(16,1),pad=(1,1),text_color='#1a2835',background_color='#a5afc9',justification='left')]
            data_rows.append(row)
        return data_rows
    else:
        return [[sg.Text(' Il database è vuoto.\n Nessun materiale da mostrare. Comincia aggiungendone qualcuno:\n         >> Modifica i materiali nel databse  >> Aggiungi nuovo materiale', text_color='red')]]



def input_table_layout(dbase,indexes,table_heads):
    '''
    
    '''
    if len(indexes)>0:
        data_rows = []
        # we write each row as a list, then we sum all of them inside of a list of lists
        for line in indexes:
            row = []
            for col in range(len(table_heads)):
                text = (dbase.at[line, table_heads[col]]) # this text is read inside the dataframe 'dbase'
                
                # we remove the units of measure
                if table_heads[col] == 'weight':
                    text = text.strip(' kg')
                if table_heads[col] == 'quotation':
                    text = text.strip(' €/kg')
                
                # we compose the row, the key is going to correspond to the column head + the linne number
                row += [sg.InputText(default_text=text,size=(18,1),pad=(1,1),text_color='#1a2835',background_color='#a5afc9',key=(table_heads[col] + ' ' + str(line)))]
            
            # we add the composed row to the list of rows
            data_rows.append(row)
        return data_rows
    else:
        return None
    
    

def get_dict_with_dataframe_values(dbase, indexes, head_names):
    '''
    
    '''
    if len(indexes)>0:
        output_dict = {}
        for line in indexes:
            for col in range(len(head_names)):
                data = (dbase.at[line, head_names[col]]) # this text is read inside the dataframe 'dbase'
                
                output_dict[head_names[col] + ' ' + str(line)] = data
                
        return output_dict
    else:
        return None
