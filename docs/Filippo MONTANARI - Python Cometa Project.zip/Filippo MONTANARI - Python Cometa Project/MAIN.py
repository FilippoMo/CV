import pandas as pd
import main_window as mw

'''
The main file loads the database and opens the main GUI window
'''



# --- LOADING THE DATABASE ---- #
file = '.stocked_materials_database.txt'
try:
    dbase = pd.read_csv(file)
except:
    f = open(file, "a")
    f.write("material,weight,quotation,tot_value,zone,last_insertion")
    f.close()
    dbase = pd.read_csv(file)
# ----------------------------- #


# -------- GUI options -------- #
title = 'COMETA Project'
theme = 'DarkBlue'
cometa_icon = 'Cometa_logo.ico'
options = ()
dbase_heads = ['material', 'weight', 'quotation', 'tot_value', 'zone', 'last_insertion']
table_headings = ['Materiale', "Quantita'", 'Quotazione', 'Valore in stock', 'Zona di stoccaggio', 'Ultima inserzione']

# ------ Menu Definition ------ #
menu_def = [['&File', ['&Open', '&Save', 'E&xit', 'Properties']],
            ['&Edit', ['Paste', ['Special', 'Normal', ], 'Undo'], ],
            ['&Help', '&About...'], ]


# --- OPENING MAIN WINDOW ---- #
mw.open_main_window(file, dbase, title, theme, cometa_icon, options, menu_def, dbase_heads, table_headings)





