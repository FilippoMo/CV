import PySimpleGUI as sg
import material_in_out as io
import different_operations as dops
import edit_database_window as edit_db
import update_quotations_window as up_quot



def open_main_window(file, dbase, win_title, theme, icon, options, menu_def, dbase_heads, table_headings):
    sg.theme(theme)
    sg.SetOptions(options)
    
    header =  [[sg.Text(h,size=(15,1),justification='center') for h in table_headings]]
    
    # we build the table to insert into the layout:
    table = header + dops.text_table_layout(dbase,list(dbase.index.values),dbase_heads)
    
    # ------ Layout Definition ------ #
    layout = [
        [sg.Menu(menu_def, tearoff=True)],
        
        # First column: entering/exiting material
        [sg.Column([
            [sg.Frame(layout=[
                [sg.InputCombo(dops.get_dbase_column_as_list(dbase,'material'), size=(23, 1), key='-MATERIAL_IN-')],
                [sg.Text("Quantita' in Kg", size=(13, 1), justification='right'),
                sg.InputText(size=(8, 1),do_not_clear=False, key='-WEIGHT_IN-')],
                [sg.Submit(button_text='Conferma',tooltip='CLicca per registrare il materiale in entrata',key='-CONFERMA_IN-')]], 
                title='Materiale in entrata',font='bold')],
            
            [sg.Text(' '*27 + '    ')], # vertical separator
        
            [sg.Frame(layout=[
                [sg.InputCombo(dops.get_dbase_column_as_list(dbase,'material'), size=(23, 1), key='-MATERIAL_OUT-')],
                [sg.Text("Quantita' in Kg", size=(13, 1), justification='right'),
                sg.InputText(size=(8, 1), do_not_clear=False, key='-WEIGHT_OUT-')],
                [sg.Submit(button_text='Conferma',tooltip='CLicca per registrare il materiale in uscita',key='-CONFERMA_OUT-')]], 
                title='Materiale in uscita',font='bold')],
            
            [sg.Text(' '*27 + '    ')], # vertical separator
            
            [sg.Button(button_text='Aggiorna quotazioni',size=(23, 1))],
            [sg.Button(button_text='Modifica i materiali nel database',size=(23, 1))],
            
            ]),
        
        # Second column: table resuming stocked materials
        sg.Column([
            [sg.Frame(layout = table,title='Materiali in stock',font='bold')]
            ])],
        
        [sg.Text(' '*227), sg.Cancel(button_text='Chiudi',size=(12, 1),button_color=('#1a2835','#a5afc9'),tooltip='Arresta il programma')]
        
        ]
    
    # -------- READING INPUT ------- #
    main_window = sg.Window(win_title, layout, icon=icon, grab_anywhere=True)
    
    event = ''
    while event != 'Chiudi' and event != sg.WIN_CLOSED:
        event, values = main_window.read()
        
        # -CONFERMA_IN- --> record of IN material
        if event == '-CONFERMA_IN-':
            new_dbase = io.in_material(file, dbase, values['-MATERIAL_IN-'], values['-WEIGHT_IN-'])
            main_window.close()
            return open_main_window(file, new_dbase, win_title, theme, icon, options, menu_def, dbase_heads, table_headings)
        
        # -CONFERMA_OUT- --> record of OUT material
        elif event == '-CONFERMA_OUT-':
            new_dbase = io.out_material(file, dbase, values['-MATERIAL_OUT-'], values['-WEIGHT_OUT-'])
            main_window.close()
            return open_main_window(file, new_dbase, win_title, theme, icon, options, menu_def, dbase_heads, table_headings)
            
            #main_window['-MATERIAL_OUT-'].update([]) # clearing the field
        
        # Aggiorna quotazioni --> update quotations
        elif event == 'Aggiorna quotazioni':
            new_dbase = up_quot.open_window(file, dbase, icon)
            if not new_dbase is None:
                main_window.close()
                return open_main_window(file, new_dbase, win_title, theme, icon, options, menu_def, dbase_heads, table_headings)
            
        # Modifica i materiali nel database --> edit database
        elif event == 'Modifica i materiali nel database':
            new_dbase = edit_db.open_window(file, dbase, icon)
            main_window.close()
            return open_main_window(file, new_dbase, win_title, theme, icon, options, menu_def, dbase_heads, table_headings)
        
    
        
    main_window.close()

