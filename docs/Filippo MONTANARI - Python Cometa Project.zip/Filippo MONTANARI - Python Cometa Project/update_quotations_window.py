import PySimpleGUI as sg
import different_operations as dops

'''

'''

def open_window(file, dbase, win_icon):
    
    # ---- list of the materials ----- #
    materials = dops.get_dbase_column_as_list(dbase,'material')
    
    # --- current quotation values --- #
    old_quot_values = dops.get_dbase_column_as_list(dbase,'quotation')
    # if database is empty show a popup message and return None
    if len(old_quot_values) == 0:
        sg.Popup(' Il database è vuoto.\nImpossibile aggiornare le quotazioni.')
        return None
    
    
    # --- layout elements definition --- #
    quotations = []
    for i in range(len(old_quot_values)):
        default_txt = old_quot_values[i].strip(' €/kg')
        row = [sg.Text(materials[i],size=(15,1),justification='right'),
               sg.InputText(default_text=default_txt,size=(10,1),pad=(1,1),text_color='#1a2835',background_color='#a5afc9',key=i), 
               sg.Text('€/kg')]
        quotations.append(row)

    confirm_button = [sg.Submit(button_text='Salva', size=(9,1), tooltip='Salva e chiudi la finestra')]
    cancel_button = [sg.Cancel(button_text='Annulla', size=(9,1), tooltip='Chiudi senza salvare')]
        
    # --- layout composition --- #
    layout = quotations + [confirm_button + cancel_button]
        
    # --- Window opening --- #
    up_quot_window = sg.Window('Aggiorna quotazione', layout, icon=win_icon)
    
    
    event = ''
    while event != 'Annulla' and event != sg.WIN_CLOSED:
        event, new_quotations = up_quot_window.read()
        
        if event == 'Salva':
            dbase = update_quotations(file, dbase, win_icon, materials, new_quotations)
            dbase.to_csv(file, index=False)
            up_quot_window.close()
            return dbase
    
    up_quot_window.close()
    return None



#%% --- UPDATE quotation values in the database --- #
def update_quotations(file, dbase, win_icon, materials_list, new_quotations_dict):
    
    ans = check_and_format_quotations(new_quotations_dict, materials_list)
    
    if ans is None:
        return open_window(file, dbase, win_icon)
    
    else:
        new_quotations_dict = ans
        
        # get weights
        weights = dops.get_dbase_column_as_list(dbase, 'weight')
        
        for index in new_quotations_dict.keys():
            
            # updating quotation
            dbase.at[int(index), 'quotation'] = new_quotations_dict[index]
            
            # updating tot_value in stock
            dbase.at[int(index), 'tot_value'] = dops.calculate_tot_value(weights[index], new_quotations_dict[index])
        
        return dbase



#%% --- CHECK if quotations have the correct format --- #
def check_and_format_quotations(quotations, materials_list):
    not_valid = []
    
    for index in quotations.keys():
        try:
            value = quotations[index]
            value = "{:.2f}".format(float(value.replace(',','.')))
            quotations[index] = str(value).replace('.',',') + ' €/kg'
        except:
            not_valid.append(materials_list[index])
    
    if len(not_valid) == 0:
        return quotations
    else:
        materials_str = ''
        for material in not_valid:
            materials_str += '  -- ' + material + '\n'
        
        sg.Popup('Le quotazioni di:\n' + materials_str + 'non sono valide.', grab_anywhere=True)
